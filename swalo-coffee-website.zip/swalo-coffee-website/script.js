// Ganti tautan toko ShopeeFood di bagian SHOPEE_URL jika sudah tersedia.
const WHATSAPP_NUMBER = "6281295955034"; // nomor Indonesia tanpa angka 0 di depan
const SHOPEE_URL = ""; // contoh: https://shopee.co.id/universal-link/...
const toast = document.querySelector(".toast");
let toastTimer;
function showToast(message){toast.textContent=message;toast.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove("show"),3200)}
function openWhatsApp(message){
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  window.open(url,"_blank","noopener,noreferrer");
}
document.querySelectorAll("[data-order]").forEach(link=>link.addEventListener("click",event=>{
  event.preventDefault();
  openWhatsApp("Halo Swalo Coffee! Saya ingin melihat menu dan melakukan pemesanan. Bisa dibantu?");
}));
document.querySelector("[data-loyalty]").addEventListener("click",event=>{
  event.preventDefault();
  openWhatsApp("Halo Swalo Coffee! Saya ingin bertanya dan mendaftar Swalo Loyalty Card. Bagaimana caranya?");
});
document.querySelector("[data-shopee]").addEventListener("click",event=>{
  if(!SHOPEE_URL){event.preventDefault();showToast("Tautan ShopeeFood resmi belum dipasang. Edit SHOPEE_URL di script.js.");return}
  event.preventDefault();window.open(SHOPEE_URL,"_blank","noopener,noreferrer");
});
const toggle=document.querySelector(".menu-toggle");
const nav=document.querySelector(".desktop-nav");
toggle.addEventListener("click",()=>{const open=nav.classList.toggle("open");toggle.setAttribute("aria-expanded",String(open));toggle.textContent=open?"×":"☰"});
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");toggle.setAttribute("aria-expanded","false");toggle.textContent="☰"}));
document.querySelector("#year").textContent=new Date().getFullYear();
