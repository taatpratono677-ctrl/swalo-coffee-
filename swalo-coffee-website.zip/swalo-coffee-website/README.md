# Swalo Coffee — Website

Website statis responsif untuk Swalo Coffee. Dibuat dengan HTML, CSS, dan JavaScript tanpa proses build.

## Struktur file

- `index.html` — konten dan struktur halaman
- `style.css` — desain responsif
- `script.js` — tautan WhatsApp, navigasi mobile, dan akses ShopeeFood
- `assets/images/` — tempat foto asli

## Cara menjalankan di perangkat sendiri

Buka `index.html` di browser. Untuk pengujian lebih baik, gunakan ekstensi Live Server di VS Code.

## Cara menerbitkan gratis dengan Netlify

1. Ekstrak ZIP ini.
2. Buka https://app.netlify.com/drop di browser.
3. Masuk/daftar akun Netlify jika diminta.
4. Seret folder `swalo-coffee-website` (folder yang berisi `index.html`, bukan file ZIP) ke area unggah Netlify. Jika HP tidak mendukung seret folder, ekstrak ZIP dan unggah melalui komputer atau gunakan GitHub + Netlify.
5. Tunggu proses selesai. Netlify akan memberi alamat publik `*.netlify.app`.
6. Buka alamat tersebut dari browser lain/HP untuk menguji.

## Cara unggah dengan GitHub Pages

1. Buat repositori baru di https://github.com/new.
2. Unggah `index.html`, `style.css`, `script.js`, dan folder `assets`.
3. Di Settings → Pages, pilih deploy dari branch `main` dan folder `/ (root)`.
4. Simpan, lalu tunggu alamat publik muncul.

## Sebelum dipublikasikan

- Pastikan nomor WhatsApp di `script.js` benar: `6281295955034`.
- Periksa harga, nama menu, promo, jam operasional, dan lokasi.
- `SHOPEE_URL` di `script.js` masih kosong. Isi dengan tautan toko ShopeeFood resmi; tombol saat ini akan menampilkan pemberitahuan.
- Foto masih berupa tempat sementara. Tambahkan foto asli dengan nama berikut:
  - `assets/images/manual-brew.jpg`
  - `assets/images/takeover-bar.jpg`
  - `assets/images/street-coffee.jpg`
  Gunakan foto milik sendiri atau foto yang memang memiliki izin untuk dipakai.
- Loyalty card pada versi ini masih contoh visual; belum menyimpan transaksi atau stempel pelanggan. Untuk pencatatan nyata perlu backend/database.
- Google Maps diarahkan ke hasil pencarian “Lapangan Pemda Sleman, Yogyakarta”. Jika punya pin lokasi tepat, ganti URL di `index.html`.
- Promo dan harga mengikuti data referensi yang diberikan. Verifikasi sebelum tayang.

## Catatan teknis

Font dari Google Fonts memerlukan internet; jika tidak tersedia, situs memakai font pengganti. Website ini tidak memiliki backend dan tidak memproses pembayaran.
