Simpan foto asli di folder ini dengan nama manual-brew.jpg, takeover-bar.jpg, dan street-coffee.jpg. Lihat README.md di folder utama.
